         // chapter 38-42

//  1. Write a custom function power ( a, b ), to calculate the value of
//  a raised to b.

// function power(){
//     var a = prompt("Enter the base ");
//     var b = prompt("Enter the power");
//     var result = Math.pow(a, b);
//     alert("the result power is" + " " + result);
// }
// power();


// 2. Any year is entered through the keyboard. Write a function to
// determine whether the year is a leap year or not.

// function date(){
//     var currentDate = new Date();
//     var year = currentDate.getFullYear();
//     var date = new Date(prompt("Enter year"));
//     var year2 = date.getFullYear();
//     var leap = year - year2;
//     document.write("The leap of year between"+ " " + year + " " + "&" + " " + year2 + " " + "is" + " "+leap );
// }
// date(); 


// 3. If the lengths of the sides of a triangle are denoted by a, b, and
// c, then area of triangle is given by
// area = S(S − a)(S − b)(S − c)
// where, S = ( a + b + c ) / 2

// function triangle(){
//     var a = +prompt("Enter value of triangle = a");
//     var b = +prompt("Enter value of triangle = b");
//     var c = +prompt("Enter value of triangle = c");
//     var s = (a + b + c)/2;
//     alert("The area of triangle is:" +  " "+s);
// }
// triangle();

// function triangle(){
//     var a = +prompt("Enter value of triangle = a");
//     var b = +prompt("Enter value of triangle = b");
//     var c = +prompt("Enter value of triangle = c");
//     var s = (a + b + c)/2;
//     var area = s*(s-a)*(s-b)*(s-c);
    
//     alert("The area of triangle is:" +  " "+area);
// }
// triangle();

// 5. You have learned the function indexOf. Code your own custom
// function that will perform the same functionality. You can code
// for single character as of now.


// function index(){
//         var array = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];
//         var usear = prompt("Enter any of day name");
//  var ind = array.indexOf(usear);
//   alert(ind);
// }
// index();


// 6. Write a function to delete all vowels from a sentence. Assume
// that the sentence is not more than 25 characters long.

// var strings = ["A paragraph is a group of sentences that fleshes out a single idea. In order for a paragraph to be effective, it must begin with a topic sentence, have sentences that support the main idea of that paragraph, and maintain a consistent flow."];
// string = strings. map(x=>x. replace( /[aeiou]/g, '' ));
// document.write(string);

// 7. Write a function with switch statement to count the number of
// occurrences of any two vowels in succession in a line of text.

// function vowel_count(str1)
// {
//   var vowel_list = 'aeiouAEIOU';
//   var vcount = 0;
  
//   for(var x = 0; x < str1.length ; x++)
//   {
//     if (vowel_list.indexOf(str1[x]) !== -1)
//     {
//       vcount += 1;
//     }
  
//   }
//   return vcount;
// }
// document.write("“Pleases read this application and give me gratuity”"+ "<br>" +"Number of vowels is" +" " +vowel_count("“Pleases read this application and give me gratuity”"));

                     //Chapter 43-48
//  1. Show an alert box on click on a link.

// function alertBox(){
//     alert("Hy usear");
// }


// 2. Display some Mobile images in browser. On click on an
// image Show the message in alert to user.

// function phone(){
//     alert("Thanks for purchasing a phone from us")
// }


// 3. Display 10 student records in table and each row should contain a delete
// button. If you click on a button to delete a record, entire row should be
// deleted.

        //     function delete_row(no)
        // {
        //  document.getElementById("row"+no+"").outerHTML="";
        // }


// 4. Display an image in browser. Change the picture on mouseover and set the
// first picture on mouseout.

// function getNewImage(){
// document.getElementById("image1").src = "image/firefox.png"
// }

// function getOldImage(){
//     document.getElementById("image1").src = "image/chrom.jpg"
// }




// 5. Show a counter in browser. Counter should increase on click on increase
// button and decrease on click on decrease button. And show updated counter
// value in browser.

// document.querySelector(".minus-btn").setAttribute("disabled", "disabled");

// var valueCount
//  //add button
// document.querySelector(".plus-btn").addEventListener("click", function() {
//     valueCount = document.getElementById("quantity").value;
//     valueCount++;
//     document.getElementById("quantity").value = valueCount;
    
//     if (valueCount > 0){
//         document.querySelector(".minus-btn").removeAttribute("disabled");
//         document.querySelector(".minus-btn").classList.remove("disabled");
//     }
// })
//  //substract button
// document.querySelector(".minus-btn").addEventListener("click", function() {
//     valueCount = document.getElementById("quantity").value;
//     valueCount--;
//     document.getElementById("quantity").value = valueCount;

//     if (valueCount == 0){
//         document.querySelector(".minus-btn").setAttribute("disabled", "disabled")
//     }
// })

